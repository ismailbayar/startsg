<?php
header("Content-Type:image/jpeg");
echo file_get_contents("http://159.253.33.44/resim.php");
?>
